last_name = input("What's your lastname? ")
print("You are now in " + last_name + " World!")
