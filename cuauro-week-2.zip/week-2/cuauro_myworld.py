# ==========================
# Title: cuauro_myworld.py
# Author: Richard Krasso
# Modified by: Patrick Cuauro
# Date: 31 May 2023
# Description: Exercise 2.3
# ==========================
# variable declaration to store last name input from user
last_name = input("What's your lastname? ")
# show value of the variable
print("You are now in " + last_name + " World!")
